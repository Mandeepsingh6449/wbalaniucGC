package com.example.countdown

import android.os.Bundle
import android.os.CountDownTimer
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var textViewCountdown: TextView
    private lateinit var editTextInput: EditText
    private lateinit var buttonStartPause: Button
    private lateinit var buttonReset: Button
    private lateinit var buttonPlus1: Button
    private lateinit var buttonPlus5: Button
    private lateinit var buttonPlus10: Button

    private var countDownTimer: CountDownTimer? = null
    private var timerRunning = false
    private var timeLeftInMillis: Long = 0
    private var startTimeInMillis: Long = 0
    private var addedTimeInMillis: Long = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        buttonStartPause.setOnClickListener {
            if (timerRunning) {
                pauseTimer()
            } else {
                startTimer()
            }
        }

        buttonReset.setOnClickListener {
            resetTimer()
        }

        buttonPlus1.setOnClickListener {
            addTime(1000)
        }

        buttonPlus5.setOnClickListener {
            addTime(5000)
        }

        buttonPlus10.setOnClickListener {
            addTime(10000)
        }
    }

    override fun setContentView(activityMain: Int) {

    }

    private fun startTimer() {
        val input = editTextInput.text.toString()
        if (input.isEmpty()) {
            return
        }

        val millisInput = input.toLong() * 1000
        if (millisInput == 0L) {
            return
        }

        startTimeInMillis = millisInput
        timeLeftInMillis = millisInput

        countDownTimer = object : CountDownTimer(timeLeftInMillis, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                timeLeftInMillis = millisUntilFinished
                updateCountdownText()
            }

            override fun onFinish() {
                timerRunning = false
                updateWatchInterface()
            }
        }.start()

        timerRunning = true
        updateWatchInterface()
    }

    private fun pauseTimer() {
        countDownTimer?.cancel()
        timerRunning = false
        updateWatchInterface()
    }

    private fun resetTimer() {
        timeLeftInMillis = startTimeInMillis
        addedTimeInMillis = 0
        updateCountdownText()
        updateWatchInterface()
    }

    private fun addTime(millis: Long) {
        if (timerRunning) {
            return
        }

        addedTimeInMillis += millis
        timeLeftInMillis += millis
        updateCountdownText()
    }

    private fun updateCountdownText() {
        val minutes = (timeLeftInMillis + addedTimeInMillis) / 1000 / 60
        val seconds = (timeLeftInMillis + addedTimeInMillis) / 1000 % 60
        val milliseconds = (timeLeftInMillis + addedTimeInMillis) % 1000 / 10

        val timeLeftFormatted = String.format("%02d:%02d:%02d", minutes, seconds, milliseconds)
        textViewCountdown.text = timeLeftFormatted
    }

    private fun updateWatchInterface() {}

    private fun Any.onCreate(savedInstanceState: Bundle?) {

    }
}