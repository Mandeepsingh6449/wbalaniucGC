package com.example.secretmessage

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import androidx.fragment.app.replace
import androidx.navigation.findNavController

class MessageFragment : Fragment() {


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_message, container, false)
        val backButton = view.findViewById<Button>(R.id.next)
        val messageView= view.findViewById<EditText>(R.id.message)
        val messageView1= view.findViewById<EditText>(R.id.message1)
        val chk1 = view.findViewById<CheckBox>(R.id.yes )
        val chk2 = view.findViewById<CheckBox>(R.id.no )

        // Inflate the layout for this fragment
        backButton.setOnClickListener {

            if (chk2.isChecked) {

                val message = messageView.text.toString()
                val action =
                    MessageFragmentDirections.actionMessageFragmentToEncryptFragment(message)

                view.findNavController().navigate(action)
            }
            if (chk1.isChecked) {
                val message2 = messageView.text.toString()
                val message=message2.reversed()

                val action =
                    MessageFragmentDirections.actionMessageFragmentToEncryptFragment(message)

                view.findNavController().navigate(action)
            }
        }
        // Inflate the layout for this fragment
       return view


    }

}